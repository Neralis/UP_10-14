﻿using System;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        string inputText = "АхахахаАХАХахахаХАфыахА";

        string result = ChangeLettersInWords(inputText);


        Console.WriteLine("Ввод: АхахахаАХАХахахаХАфыахА");
        Console.WriteLine("Результат: " +result);
    }

    static string ChangeLettersInWords(string input)
    {
        string pattern = "А";
        string replacement = "*";
        return Regex.Replace(input, pattern, replacement);
    }
}
