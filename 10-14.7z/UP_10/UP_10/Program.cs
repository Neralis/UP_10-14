﻿using System;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        string inputText = "Sample Text Something CHEMK ConsoleApp";

        Console.WriteLine("Введите номер первого сивола (i):");
        if (int.TryParse(Console.ReadLine(), out int iPosition))
        {
            Console.WriteLine("Введите номер второго сивола (j):");
            if (int.TryParse(Console.ReadLine(), out int jPosition))
            {
                string result = SwapLettersInWords(inputText, iPosition, jPosition);
                Console.WriteLine("Результат:");
                Console.WriteLine(result);
            }
            else
            {
                Console.WriteLine("Неправильная позиция j.");
            }
        }
        else
        {
            Console.WriteLine("Неправильная позиция i");
        }
    }

    static string SwapLettersInWords(string input, int i, int j)
    {
        string pattern = @"\b(\w)(\w{" + (i - 1) + @"})(\w)(\w{" + (j - i - 1) + @"})(\w+)\b";
        string replacement = "$1$4$3$2$5";
        return Regex.Replace(input, pattern, replacement);
    }
}
