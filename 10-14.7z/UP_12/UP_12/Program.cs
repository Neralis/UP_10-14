﻿using System;

namespace MyApp // Note: actual namespace depends on the project name.
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("a: ");
            double a = Convert.ToDouble(Console.ReadLine());

            Console.Write("b: ");
            double b = Convert.ToDouble(Console.ReadLine());

            Console.Write("c: ");
            double c = Convert.ToDouble(Console.ReadLine());

            Console.Write("d: ");
            double d = Convert.ToDouble(Console.ReadLine());

            double minAB = Min(a, b);
            double minCD = Min(c, d);

            double minOverall = Min(minAB, minCD);
            double maxOverall = Max(a, b, c, d); // Corrected line

            Console.WriteLine("Min: " + minOverall);
            Console.WriteLine("Max: " + maxOverall);
        }

        static double Min(double x, double y)
        {
            return x < y ? x : y;
        }

        static double Max(double w, double x, double y, double z)
        {
            double temp1 = x > y ? x : y;
            double temp2 = z > w ? z : w;
            return temp1 > temp2 ? temp1 : temp2;
        }
    }
}
