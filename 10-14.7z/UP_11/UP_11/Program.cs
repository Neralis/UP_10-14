﻿using System;

namespace MyApp // Note: actual namespace depends on the project name.
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите имя");
            string name = Console.ReadLine();
            Console.WriteLine("Введите a");
            double a = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Введите b");
            double b = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Введите c");
            double c = Convert.ToDouble(Console.ReadLine());

            Triangle t = new Triangle(name, a, b, c);
            t.ShowSides();
            t.P();
            t.S();
        }
    }

    public class Triangle
    {
        double a;
        double b;
        double c;

        string name;

        public Triangle(string name, double a, double b, double c)
        {
            this.name = name;
            this.a = a;
            this.b = b;
            this.c = c;
        }

        public void ShowSides()
        {
            Console.WriteLine(name);
            Console.WriteLine($"a = {a}, b = {b}, c = {c}");
        }

        public void P()
        {
            double p = a + b + c;
            Console.WriteLine(p);
        }

        public void S()
        {
            if (a + b > c && a + c > b && b + c > a)
            {
                // Полупериметр
                double s = (a + b + c) / 2;

                // Формула Герона
                double area = Math.Sqrt(s * (s - a) * (s - b) * (s - c));
                Console.WriteLine(area);

            }
            else
            {
                // Если треугольник не существует, возвращаем NaN
                Console.WriteLine("NaN");
            }
        }
    }
}
