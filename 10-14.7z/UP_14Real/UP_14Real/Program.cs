﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Globalization;

class Student
{
    public string FullName { get; set; }
    public int BirthYear { get; set; }
    public string HomeAddress { get; set; }
    public string GraduatedSchool { get; set; }
}

class Program
{
    static void Main(string[] args)
    {
        string inputFile = "input.txt";
        string outputFile = "output.txt";
        string targetSchool = "№123"; // Замените "Target School" на название нужной школы

        List<Student> students = ReadStudentsFromFile(inputFile);
        List<Student> targetSchoolStudents = FilterStudentsBySchool(students, targetSchool);
        List<Student> sortedStudents = SortStudentsByBirthYear(targetSchoolStudents);

        WriteStudentsToFile(outputFile, sortedStudents);

        Console.WriteLine("Результаты записаны в файл output.txt");
    }

    static List<Student> ReadStudentsFromFile(string filePath)
    {
        List<Student> students = new List<Student>();

        string[] lines = File.ReadAllLines(filePath);

        foreach (string line in lines)
        {
            string[] parts = line.Split(',');

            Student student = new Student
            {
                FullName = parts[0],
                BirthYear = int.Parse(parts[1]),
                HomeAddress = parts[2],
                GraduatedSchool = parts[3]
            };

            students.Add(student);
        }

        return students;
    }

    static List<Student> FilterStudentsBySchool(List<Student> students, string targetSchool)
    {
        return students.Where(s => s.GraduatedSchool == targetSchool).ToList();
    }

    static List<Student> SortStudentsByBirthYear(List<Student> students)
    {
        return students.OrderBy(s => s.BirthYear).ToList();
    }

    static void WriteStudentsToFile(string filePath, List<Student> students)
    {
        using (StreamWriter writer = new StreamWriter(filePath))
        {
            foreach (var student in students)
            {
                writer.WriteLine($"{student.FullName},{student.BirthYear},{student.HomeAddress},{student.GraduatedSchool}");
            }
        }
    }
}
