﻿using System;

class DemoPoint : IComparable
{
    protected int x;
    protected int y;

    public DemoPoint(int x, int y)
    {
        this.x = x;
        this.y = y;
    }

    public void Show()
    {
        Console.WriteLine("точка на плоскости: ({0}, {1})", x, y);
    }

    public double Dlina()
    {
        return Math.Sqrt(x * x + y * y);
    }

    public int CompareTo(object obj)
    {
        DemoPoint b = (DemoPoint)obj;
        if (this.Dlina() == b.Dlina()) return 0;
        else if (this.Dlina() > b.Dlina()) return 1;
        else return -1;
    }

    public static bool operator ==(DemoPoint a, DemoPoint b)
    {
        return (a.CompareTo(b) == 0);
    }

    public static bool operator !=(DemoPoint a, DemoPoint b)
    {
        return (a.CompareTo(b) != 0);
    }

    public static bool operator >(DemoPoint a, DemoPoint b)
    {
        return (a.Dlina() > b.Dlina());
    }

    public static bool operator <(DemoPoint a, DemoPoint b)
    {
        return (a.Dlina() < b.Dlina());
    }

    public static bool operator >=(DemoPoint a, DemoPoint b)
    {
        return (a.Dlina() >= b.Dlina());
    }

    public static bool operator <=(DemoPoint a, DemoPoint b)
    {
        return (a.Dlina() <= b.Dlina());
    }
}

namespace MyApp // Note: actual namespace depends on the project name.
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DemoPoint a = new DemoPoint(-3, 0);
            DemoPoint b = new DemoPoint(0, 3);

            if (a == b)
                Console.WriteLine("равно удалены от начала координат");
            else
                Console.WriteLine("не равно удалено от начала координат");

            if (a > b)
                Console.WriteLine("точка 'a' дальше от начала координат, чем точка 'b'");
            else
                Console.WriteLine("точка 'a' не дальше от начала координат, чем точка 'b'");
        }
    }
}
