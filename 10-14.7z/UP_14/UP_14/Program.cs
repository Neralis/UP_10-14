﻿using System;

// Определение интерфейса
interface IDemo
{
    void Show(); // Объявление метода
    double Dlina(); // Объявление метода
    int X { get; } // Объявление свойства, доступного только для чтения
    int Y { get; } // Новое свойство Y, доступное только для чтения
    
    int this[int i] { get; set; } // Объявление индексатора, доступного для чтения-записи
}

// Класс DemoPoint наследует интерфейс IDemo
class DemoPoint : IDemo
{
    protected int x;
    protected int y;

    public DemoPoint(int x, int y)
    {
        this.x = x;
        this.y = y;
    }

    // Реализация метода, объявленного в интерфейсе
    public void Show()
    {
        Console.WriteLine("Точка на плоскости: ({0}, {1})", x, y);
    }

    // Реализация метода, объявленного в интерфейсе
    public double Dlina()
    {
        return Math.Sqrt(x * x + y * y);
    }

    // Реализация свойства X, объявленного в интерфейсе
    public int X
    {
        get
        {
            return x;
        }
    }

    // Реализация нового свойства Y, объявленного в интерфейсе
    public int Y
    {
        get
        {
            return y;
        }
    }

    // Реализация индексатора, объявленного в интерфейсе
    public int this[int i]
    {
        get
        {
            if (i == 0) return x;
            else if (i == 1) return y;
            else throw new Exception("Недопустимое значение индекса");
        }
        set
        {
            if (i == 0) x = value;
            else if (i == 1) y = value;
            else throw new Exception("Недопустимое значение индекса");
        }
    }
}

// Класс DemoShape наследует класс DemoPoint и интерфейс IDemo
class DemoShape : DemoPoint, IDemo
{
    protected int z;

    public DemoShape(int x, int y, int z) : base(x, y)
    {
        this.z = z;
    }

    // Реализация метода, объявленного в интерфейсе, с сокрытием одноименного метода из базового класса
    public new void Show()
    {
        Console.WriteLine("Точка в пространстве: ({0}, {1}, {2})", x, y, z);
    }

    // Реализация метода, объявленного в интерфейсе, с сокрытием одноименного метода из базового класса
    public new double Dlina()
    {
        return Math.Sqrt(x * x + y * y + z * z);
    }

    // Реализация нового свойства Z, объявленного в интерфейсе
    public int Z
    {
        get
        {
            return z;
        }
    }

    // Реализация индексатора, объявленного в интерфейсе, с сокрытием одноименного индексатора из базового класса
    public new int this[int i]
    {
        get
        {
            if (i == 0) return x;
            else if (i == 1) return y;
            else if (i == 2) return z;
            else throw new Exception("Недопустимое значение индекса");
        }
        set
        {
            if (i == 0) x = value;
            else if (i == 1) y = value;
            else if (i == 2) z = value;
            else throw new Exception("Недопустимое значение индекса");
        }
    }
}

class Program
{
    static void Main()
    {
        // Создание массива интерфейсных ссылок
        IDemo[] a = new IDemo[4];

        // Заполнение массива
        a[0] = new DemoPoint(0, 1);
        a[1] = new DemoPoint(-3, 0);
        a[2] = new DemoShape(3, 4, 0);
        a[3] = new DemoShape(0, 5, 6);

        // Просмотр массива
        foreach (IDemo x in a)
        {
            x.Show();
            Console.WriteLine("Dlina={0:f2}", x.Dlina());
            Console.WriteLine("X={0}, Y={1}, Z={2}", x.X, x.Y, (x is DemoShape) ? ((DemoShape)x).Z : 0);
            x[1] += x[0];
            Console.Write("Новые координаты - ");
            x.Show();
            Console.WriteLine();
        }
    }
}
